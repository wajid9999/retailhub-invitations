VELVET CURTAIN CARD – WEBSITE PACKAGE
=====================================

Files
-----
templates.html                 -> your gallery page (thumbnails, Preview, Order on WhatsApp)
velvet-curtain/index.html      -> the card (demo copy with SAMPLE watermark)
velvet-curtain/thumb.jpg       -> thumbnail (9:16)

1) Put it on your website (GitHub Pages)
----------------------------------------
- Upload both the templates.html file and the velvet-curtain folder to the SAME place in your repo.
- Your gallery opens at:  yoursite.com/templates.html
- Open templates.html in a text editor and change WA="923000000000" to your WhatsApp number.
- To link it from your menu: add a link to templates.html.

2) For each customer (after payment)
------------------------------------
- Copy the velvet-curtain folder and rename it, e.g.  cards/ahmad-mawra
- Open cards/ahmad-mawra/index.html in a text editor.
- Near the top find the block marked "EDIT ONLY THIS BLOCK". Change:
    groom, bride, events (name, hosts, date, time, timeText, venue, address, dress, map), faq
  To add an event copy one {...} line inside events. Dates are YYYY-MM-DD, time is 24-hour (16:00).
- Change  sample:true  to  sample:false  (this removes the SAMPLE watermark).
- Also change the names in the opening screen (search for "Hamza" near the bottom of the page body).
- Send the customer:  yoursite.com/cards/ahmad-mawra/

3) New designs later
--------------------
- Send me the new animation video and I will build it the same way (your video plays exactly as made).
- Add one line in TEMPLATES inside templates.html, and a new folder with index.html and thumb.jpg.

Notes
-----
- Customers open the card with a tap: the video and its sound only start after the "Tap to open" tap.
- og:image in index.html is "thumb.jpg". For a WhatsApp link preview to show it, replace it with the full
  address, e.g. https://yoursite.com/cards/ahmad-mawra/thumb.jpg
- The thumbnail uses a standard font for the names. The card itself uses the script font.
