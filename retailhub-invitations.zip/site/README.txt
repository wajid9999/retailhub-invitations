NAYA TEMPLATE JODNE KA TAREEQA
1. Naye template ki HTML file "templates" folder mein upload karen (e.g. templates/blue-lantern.html).
2. Uski chhoti tasveer "thumbs" folder mein upload karen (e.g. thumbs/blue-lantern.jpg).
3. "templates.json" mein "templates" ki list mein ek entry jod den:
 {"id":"blue","name":"Blue Lantern","tag":"Short description","file":"templates/blue-lantern.html","thumb":"thumbs/blue-lantern.jpg","occasion":"wedding","tier":"high","fam":true}
 (pichli entry ke baad comma lagana na bhoolen.)
"occasion" wahi id likhen jo "occasions" ki list mein hai (wedding, birthday, islamic, homedawat, officedawat, family, other).
"tier" ya to simple, premium ya high. Naya occasion ya tier chahiye to usi file ki list mein ek line jod den.
Qeemat dikhani ho to "tiers" mein "price" likh den, e.g. "price":"PKR 2,500".
Gallery mein naya card khud aa jayega. index.html ko haath nahi lagana.

Template ka contract: wo link ke hash se base64 JSON leta hai.
Shaadi: {final, d:{groom,bride,gf,bf,close,ev:[{k,hosts,d,t,v,a}]}}
Baqi events: {final, d:{kind:'event',title,host,close,ev:[{k,d,t,v,a}]}}
final:true par SAMPLE watermark hata do. (Purane do template apne adapter se chalte hain.)
